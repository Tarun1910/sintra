<div class="job-manager-form wp-job-manager-bookmarks-form">
	<div><a href="#login-dialog" class="small-dialog popup-with-zoom-anim bookmark-notice button dark bookmark-notice"><?php printf( esc_html__( 'Login to bookmark this %s', 'workscout' ), $post_type->labels->singular_name ); ?></a></div>
</div>