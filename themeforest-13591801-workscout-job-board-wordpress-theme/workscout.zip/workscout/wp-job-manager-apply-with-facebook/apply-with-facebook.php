<?php wp_enqueue_script( 'wp-job-manager-apply-with-facebook-js' ); ?>

<input class="apply-with-facebook apply-with-facebook-button" type="button" value="<?php _e( 'Apply with Facebook', 'workscout' ); ?>" />